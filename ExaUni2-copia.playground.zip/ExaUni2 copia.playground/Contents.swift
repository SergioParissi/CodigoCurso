//: Playground - noun: a place where people can play

import UIKit

/*
Reto dep rogramacion

generaruna serie del 1 al 100 y se imprimiran segun las siguientes reglas, si el numero es divisible entre 5 debes deimprimir la palabra bingo, si el numero es par debes imprimir el numero y la palabra par, si es impar debes de imprimir el numeroy la palabra impar, si el numero esta en el rango de 30 a 40 debes imprimir el numero mas la palabra viva Swift
*/

var cadena = 1...100

for numeros in cadena {
    if numeros % 5 == 0{
        print("\t\(numeros) Bingo ")
    }
    if numeros >= 30 && numeros <= 40{
    print("\t\(numeros) Viva Swift")
    }
     if numeros % 2 == 1{
        print("\t\(numeros) Impar")
        
    }
    else  {
        print("\t\(numeros) Par")
    }
    
}
